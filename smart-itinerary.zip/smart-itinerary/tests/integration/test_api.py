import pytest
from httpx import AsyncClient
from app.main import app


@pytest.mark.asyncio
async def test_health():
    async with AsyncClient(app=app, base_url="http://test") as client:
        r = await client.get("/health")
    assert r.status_code == 200


@pytest.mark.asyncio
async def test_register_login():
    async with AsyncClient(app=app, base_url="http://test") as client:
        r = await client.post("/api/auth/register", json={
            "name": "Test User", "email": "test@test.com",
            "password": "pass1234", "preferred_currency": "INR"
        })
        assert r.status_code == 201

        r2 = await client.post("/api/auth/login", json={
            "email": "test@test.com", "password": "pass1234"
        })
        assert r2.status_code == 200
        assert "access_token" in r2.json()


@pytest.mark.asyncio
async def test_weather_endpoint():
    async with AsyncClient(app=app, base_url="http://test") as client:
        r = await client.get("/api/weather/current/Delhi")
    assert r.status_code == 200
    data = r.json()
    assert "temperature_c" in data
